"""
Response selection methods determines which response should be used in
the event that multiple responses are generated within a logic adapter.
"""
import logging
import nltk
import gensim


def get_most_frequent_response(input_statement, response_list):
    """
    :param input_statement: A statement, that closely matches an input to the chat bot.
    :type input_statement: Statement

    :param response_list: A list of statement options to choose a response from.
    :type response_list: list

    :return: The response statement with the greatest number of occurrences.
    :rtype: Statement
    """
    matching_response = None
    occurrence_count = -1

    logger = logging.getLogger(__name__)
    logger.info(u'Selecting response with greatest number of occurrences.')

    for statement in response_list:
        count = statement.get_response_count(input_statement)

        # Keep the more common statement
        if count >= occurrence_count:
            matching_response = statement
            occurrence_count = count

    # Choose the most commonly occuring matching response
    return matching_response


def get_first_response(input_statement, response_list):
    """
    :param input_statement: A statement, that closely matches an input to the chat bot.
    :type input_statement: Statement

    :param response_list: A list of statement options to choose a response from.
    :type response_list: list

    :return: Return the first statement in the response list.
    :rtype: Statement
    """
    logger = logging.getLogger(__name__)
    logger.info(u'Selecting first response from list of {} options.'.format(
        len(response_list)
    ))
    return response_list[0]


def get_random_response(input_statement, response_list):
    """
    :param input_statement: A statement, that closely matches an input to the chat bot.
    :type input_statement: Statement

    :param response_list: A list of statement options to choose a response from.
    :type response_list: list

    :return: Choose a random response from the selection.
    :rtype: Statement
    """
    from random import choice
    logger = logging.getLogger(__name__)
    logger.info(u'Selecting a response from list of {} options.'.format(
        len(response_list)
    ))
    return choice(response_list)

def get_sentiment_response(input_statement, response_list, dm, vec_model):

    matching_reponse = None
    average_distance = 1


    #get input sentiment averages

    wordsInInput = nltk.tokenize.casual_tokenize( input_statement.text, preserve_case=False )

    numWordsFromStatementInLexicon = []

    statementMood = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0]

    # score each word and combine scores, then average
    for s in range (0,8):
        for word in wordsInInput:

            # skip punctuation and urls... could do this with the tokenizer if I had more time to read the docs!
            if len( word ) > 1 or (word == 'i' or word == 'a'):

                # If a word's not present, use the word2vec corpus to find a suitable alternative
                if word not in dm:
                    try:
                        result = vec_model.most_similar( positive=[word], topn=10 )
                        for similarWord in result:
                            if similarWord[0] in dm:
                                word = similarWord[0]
                                break
                    except KeyError:
                        break

                # [5] is happy, [7] is sad
                if word in dm:
                    statementMood[s] = statementMood[s] + dm[word][s]
                    numWordsFromStatementInLexicon[s] = numWordsFromStatementInLexicon[s] + 1

        if (numWordsFromStatementInLexicon > 0):
            statementMood[s] = statementMood[s] / numWordsFromStatementInLexicon[s]

    #for each statement
    for response in response_list:
        # get input sentiment averages

        wordsInResponse = nltk.tokenize.casual_tokenize( response.text, preserve_case=False )

        numWordsFromResponseInLexicon = []

        responseMood = []

        # score each word and combine scores, then average
        for s in range( 0, 8 ):
            for word in wordsInResponse:

                # skip punctuation and urls... could do this with the tokenizer if I had more time to read the docs!
                if len( word ) > 1 or (word == 'i' or word == 'a'):

                    # If a word's not present, use the word2vec corpus to find a suitable alternative
                    if word not in dm:
                        try:
                            result = vec_model.most_similar( positive=[word], topn=10 )
                            for similarWord in result:
                                if similarWord[0] in dm:
                                    word = similarWord[0]
                                    break
                        except KeyError:
                            break

                    # [5] is happy, [7] is sad
                    if word in dm:
                        responseMood[s] = responseMood + dm[word][s]
                        numWordsFromResponseInLexicon[s] = numWordsFromResponseInLexicon[s] + 1

            if (numWordsFromResponseInLexicon > 0):
                responseMood[s] = responseMood[s] / numWordsFromResponseInLexicon[s]

        new_average_distance = 0

        for x in range(0, 8):
            new_average_distance = new_average_distance + abs(responseMood[s]-statementMood[s])

        new_average_distance = new_average_distance / 8

        if new_average_distance < average_distance:
            matching_response = response;
            average_distance = new_average_distance


    #get distances from input
    #average them
    #if lower than previous, change to this statement
    #return response
    return matching_response
